<!DOCTYPE html>
<html>
    <head>  
        <meta charset="UTF-8">
        <link rel="stylesheet" href=""> <!--此链接留用css-->
    </head>
    <body>
        <h1>个人中心</h1>
        <?php 
            session_start();
            echo "欢迎回来：".$_SESSION["username"];
        ?> 
        <a href="logout.php">退出登录</a><br><br>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="file" accept="image">
            <input type="submit" value="上传">
        </form>
    </body>
    
</html>